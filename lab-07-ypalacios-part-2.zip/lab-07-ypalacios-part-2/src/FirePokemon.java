import java.util.ArrayList;

public class FirePokemon extends Pokemon{
    public FirePokemon(String name, int maxHP, PokemonType fire, ArrayList<Attack> AttackList) {
        super(name, maxHP, fire, AttackList);
    }
    @Override
    public int takeDamage(int damageAmount, PokemonType damageType) {
        int currentHP = getCurrentHP();
        int damage = 0;
        if (PokemonType.fire == damageType) {
        } else if (this.getType() == PokemonType.ground) {
            damage = damageAmount * 1;
        } else if (this.getType() == PokemonType.fire) {
            damage = damageAmount * 1;
        } else if (this.getType() == PokemonType.water) {
            damage = (int) (damageAmount * 0.5);
        } else if (this.getType() == PokemonType.air) {
            damage = damageAmount * 2;
        }
        currentHP -= damage;
        if (currentHP < 0) {
            currentHP = 0;
        }
        setCurrentHP(currentHP);
        return currentHP;
    }
}

