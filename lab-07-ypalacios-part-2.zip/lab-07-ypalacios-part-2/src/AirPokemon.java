import java.util.ArrayList;

public class AirPokemon extends Pokemon{

    public AirPokemon(String name, int maxHP, PokemonType air, ArrayList<Attack> AttackList) {
        super(name, maxHP, air, AttackList);
    }
    @Override
    public int takeDamage(int damageAmount, PokemonType damageType) {
        int currentHP = getCurrentHP();
        int damage = 0;
        if (PokemonType.air == damageType) {
        } else if (this.getType() == PokemonType.ground) {
            damage = damageAmount * 2;
        } else if (this.getType() == PokemonType.water) {
            damage = damageAmount * 1;
        } else if (this.getType() == PokemonType.fire) {
            damage = (int) (damageAmount * 0.5);
        } else if (this.getType() == PokemonType.air) {
            damage = damageAmount * 1;
        }
        currentHP -= damage;
        if (currentHP < 0) {
            currentHP = 0;
        }
        setCurrentHP(currentHP);
        return currentHP;
    }
}