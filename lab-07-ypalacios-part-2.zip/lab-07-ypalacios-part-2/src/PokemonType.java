public enum PokemonType {
        ground,fire,water,air
    }

