public class Attack {
    int attackStrength;
    String attackType;
    String name;

    public Attack(int attackStrength, String attackType, String name) {
        this.attackStrength = attackStrength;
        this.attackType = attackType;
        this.name = name;
    }

    public int getAttackStrength() {
        return this.attackStrength;
    }

    public void setAttackStrength(int attackStrength) {
        this.attackStrength = attackStrength;
    }

    public String getAttackType() {
        return this.attackType;
    }

    public void setAttackType(String attackType) {
        this.attackType = attackType;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
