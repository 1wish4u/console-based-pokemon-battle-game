import java.util.ArrayList;

public class WaterPokemon extends Pokemon {
    public WaterPokemon(String name, int maxHP, PokemonType type, ArrayList<Attack> attackList) {
        super(name, maxHP, type, attackList);
    }

    @Override
    public int takeDamage(int damageAmount, PokemonType damageType) {
        int currentHP = getCurrentHP();
        int damage = 0;
        if (PokemonType.water == damageType) {
        } else if (this.getType() == PokemonType.water) {
            damage = damageAmount * 1;
        } else if (this.getType() == PokemonType.fire) {
            damage = damageAmount * 2;
        } else if (this.getType() == PokemonType.ground) {
            damage = (int) (damageAmount * 0.5);
        } else if (this.getType() == PokemonType.air) {
            damage = damageAmount * 1;
        }
        currentHP -= damage;
        if (currentHP < 0) {
            currentHP = 0;
        }
        setCurrentHP(currentHP);
        return currentHP;
    }
}

