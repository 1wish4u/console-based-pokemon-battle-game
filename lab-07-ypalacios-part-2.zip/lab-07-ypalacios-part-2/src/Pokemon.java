import java.util.ArrayList;

public class Pokemon {
    private final ArrayList<Attack> AttackList;
    private String name;
    private int currentHP;
    private int maxHP;
    private PokemonType type;

    public Pokemon(String name, int maxHP, PokemonType type, ArrayList<Attack> AttackList) {
        this.name = name;
        this.currentHP = maxHP;
        this.maxHP = maxHP;
        this.type = type;
        this.AttackList = new ArrayList<Attack>();
        Attack attack1 = new Attack(20,"Fire","Fireball");
        Attack attack2 = new Attack(40,"Water","Waterblast");
        Attack attack3 = new Attack(10,"Air","airPunch");
        Attack attack4 = new Attack(30,"Ground","earthRumble");

    }
    public void addAttack(Attack attack){
        AttackList.add(attack);
    }

    public void removeAttack(int attack){
        AttackList.remove(attack);
    }
    public void showAttacks(){
        System.out.println("Attacks: ");
        for(int i = 0; i < AttackList.size(); i++){
            System.out.println(i + ": " + AttackList.get(i).getName());
        }
    }


    public void attack(Pokemon victim, int attackNumber) {
        if (attackNumber >= 0 && attackNumber < AttackList.size()) {
            Attack attack = AttackList.get(attackNumber);
            int damageAmount = attack.getAttackStrength();
            PokemonType damageType = PokemonType.valueOf(attack.getAttackType());
            victim.takeDamage(damageAmount, damageType);
        } else {
            System.out.println("Invalid attack number.");
        }
    }

    public void heal() {
        currentHP = maxHP;
        return;
    }

    public int takeDamage(int damageAmount, PokemonType damageType) {
        return damageAmount;
    }



    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCurrentHP() {
        return this.currentHP;
    }

    public void setCurrentHP(int currentHP) {
        this.currentHP = maxHP;
    }

    public int getMaxHP() {
        return this.maxHP;
    }

    public void setMaxHP(int maxHP) {
        this.maxHP = maxHP;
    }

    public PokemonType getType() {
        return this.type;
    }

    public void setType(PokemonType type) {
        this.type = type;
    }

}
