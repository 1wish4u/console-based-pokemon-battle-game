import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Attack> attackList = new ArrayList<Attack>();
        attackList.add(new Attack(20, "Fire", "Fireball"));
        attackList.add(new Attack(40, "Water", "Waterblast"));
        attackList.add(new Attack(10, "Air", "airPunch"));
        attackList.add(new Attack(30, "Ground", "earthRumble"));

        Scanner scanner = new Scanner(System.in);
        FirePokemon chariz = new FirePokemon("Chariz", 100, PokemonType.fire, attackList);
        WaterPokemon bubble = new WaterPokemon("Bubble", 80, PokemonType.water, attackList);
        AirPokemon pidgeot = new AirPokemon("Pidgeot", 90, PokemonType.air, attackList);
        GroundPokemon sandslash = new GroundPokemon("Sandslash", 95, PokemonType.ground, attackList);


        System.out.println("Welcome to the pokemon 1 on 1! ");
        System.out.println("as the first player, choose which pokemon you wish to claim");
        System.out.println("1. Bubble, a water type with two attacks, and 80 health");
        System.out.println("2. Chariz, a fire type with two attacks, and 100 health");
        System.out.println("3. pidgeot, a air type with two attacks, and 90 health");
        System.out.println("4. sandslash, a ground type with two attacks, and 95 health");
        int firstPlayer = scanner.nextInt();
        System.out.println("First player has chosen his partner to be " + firstPlayer);
        System.out.println("Second player, choose which pokemon you wish to claim");
        System.out.println("1. Bubble, a water type with two attacks, and 80 health");
        System.out.println("2. Chariz, a fire type with two attacks, and 100 health");
        System.out.println("3. pidgeot, a air type with two attacks, and 90 health");
        System.out.println("4. sandslash, a ground type with two attacks, and 95 health");
        int secondPlayer = scanner.nextInt();
        System.out.println("First player has chosen his partner to be " + secondPlayer);

        if (firstPlayer != 1 && firstPlayer != 2 && firstPlayer != 3 && firstPlayer != 4) {
            System.out.println("Invalid pokemon choice!");
        }
        if (secondPlayer != 1 && secondPlayer != 2 && secondPlayer != 3 && secondPlayer != 4) {
            System.out.println("Invalid pokemon choice!");
        }

        Pokemon player1 = null;
        Pokemon player2 = null;

        if (firstPlayer == 1) {
            player1 = bubble;
        }
        if (firstPlayer == 2) {
            player1 = chariz;
        }
        if (firstPlayer == 3) {
            player1 = pidgeot;
        } else {
            player1 = sandslash;
            if (secondPlayer == 1) {
                player2 = bubble;
            }
            if (secondPlayer == 2) {
                player2 = chariz;
            }
            if (secondPlayer == 3) {
                player2 = pidgeot;
            } else {
                player2 = sandslash;

                while (true) {
                    System.out.println("Player 1, Would you like to add, remove, or view attacks? (Type 'done' to continue)");
                    String choice = scanner.nextLine();

                    if (choice.equalsIgnoreCase("add")) {
                        player1.addAttack(new Attack(20, "Fire,", "Ember"));
                    }
                    if (choice.equalsIgnoreCase("remove")) {
                        System.out.println("Which attack do you wish to remove? choose between 1-2");
                        player1.removeAttack(scanner.nextInt());
                    }
                    if (choice.equalsIgnoreCase("view")) {
                        player1.showAttacks();
                    }
                    System.out.println("Player 2, Would you like to add, remove, or view attacks? (Type 'done' to continue)");
                    String choice2 = scanner.nextLine();

                    if (choice2.equalsIgnoreCase("add")) {
                        player2.addAttack(new Attack(20, "Fire,", "Ember"));
                    }
                    if (choice2.equalsIgnoreCase("remove")) {
                        System.out.println("Which attack do you wish to remove? choose between 1-2");
                        player2.removeAttack(scanner.nextInt());
                    }
                    if (choice2.equalsIgnoreCase("view")) {
                        player2.showAttacks();
                    }
                    System.out.println("May the best trainer win!");

                    while (player1.getCurrentHP() > 0 && player2.getCurrentHP() > 0) {
                        System.out.println("Player 1, select attack: ");
                        System.out.println("Choose between 1 or 2 attacks");
                        int attack1 = scanner.nextInt();
                        player1.attack(player2, attack1);
                        if (player2.getCurrentHP() > 0) {
                            System.out.println("Player 2, select attack: ");
                            System.out.println("Choose between 1 or 2 attacks");
                            int attack2 = scanner.nextInt();
                            player1.attack(player2, attack2);
                        }
                    }
                    System.out.println("Game over!");

                    if (player1.getCurrentHP() <= 0) {
                        System.out.println("Player 2 wins!");
                    } else {
                        System.out.println("Player 2 wins!");
                    }
                }
            }
        }
    }
}